# dupefind

Find duplicate files by content. Pure Python, no dependencies.

`dupefind` groups files by size first, then hashes only the files that share a size, so scanning large folders stays fast.

## Install

```bash
git clone https://github.com/Coolcy16/dupefind.git
cd dupefind
pip install .
```

## Usage

```bash
dupefind ~/Downloads ~/Pictures
```

```
Group 1 (2.4 MB each):
  /home/me/Downloads/photo.jpg
  /home/me/Pictures/photo-copy.jpg

1 duplicate group(s), 2.4 MB reclaimable.
```

### Options

| Option | Description |
| --- | --- |
| `--min-size BYTES` | Ignore files smaller than this (default: 1) |
| `--algorithm NAME` | `md5`, `sha1`, `sha256` (default) or `blake2b` |
| `--json` | Machine-readable output |
| `--version` | Print the version |

### Exit codes

| Code | Meaning |
| --- | --- |
| `0` | No duplicates found |
| `1` | Duplicates found |
| `2` | Invalid arguments (e.g. folder does not exist) |

`dupefind` never deletes or modifies files. It only reports.

## Use as a library

```python
from pathlib import Path
from dupefind.scanner import iter_files, find_duplicates

groups = find_duplicates(iter_files(Path("~/Downloads").expanduser()))
for digest, paths in groups.items():
    print(digest, paths)
```

## Development

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT. See [LICENSE](LICENSE).
