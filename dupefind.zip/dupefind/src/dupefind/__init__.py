"""dupefind: find duplicate files by content."""

__version__ = "0.1.0"
