"""Core logic: find duplicate files by size, then by content hash."""

from __future__ import annotations

import hashlib
import os
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, Iterator, List

CHUNK_SIZE = 1024 * 1024  # 1 MiB


def iter_files(root: Path, min_size: int = 1) -> Iterator[Path]:
    """Yield regular files under ``root`` that are at least ``min_size`` bytes.

    Symlinks are skipped so the same file is never counted twice.
    """
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            path = Path(dirpath) / name
            try:
                if path.is_symlink() or not path.is_file():
                    continue
                if path.stat().st_size >= min_size:
                    yield path
            except OSError:
                continue  # unreadable or vanished file


def hash_file(path: Path, algorithm: str = "sha256") -> str:
    """Return the hex digest of a file, read in chunks."""
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(CHUNK_SIZE), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_duplicates(
    paths: Iterable[Path], algorithm: str = "sha256"
) -> Dict[str, List[Path]]:
    """Group files with identical content.

    Files are first bucketed by size (cheap), and only files sharing a size
    are hashed. Returns ``{digest: [paths...]}`` for groups with 2+ files.
    """
    by_size: Dict[int, List[Path]] = defaultdict(list)
    for path in paths:
        try:
            by_size[path.stat().st_size].append(path)
        except OSError:
            continue

    groups: Dict[str, List[Path]] = defaultdict(list)
    for same_size in by_size.values():
        if len(same_size) < 2:
            continue
        for path in same_size:
            try:
                groups[hash_file(path, algorithm)].append(path)
            except OSError:
                continue

    return {
        digest: sorted(files)
        for digest, files in groups.items()
        if len(files) > 1
    }


def wasted_bytes(groups: Dict[str, List[Path]]) -> int:
    """Total bytes that could be reclaimed by keeping one copy per group."""
    total = 0
    for files in groups.values():
        size = files[0].stat().st_size
        total += size * (len(files) - 1)
    return total
