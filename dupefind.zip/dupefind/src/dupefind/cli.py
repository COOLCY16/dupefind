"""Command-line interface for dupefind."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import List, Optional

from . import __version__
from .scanner import find_duplicates, iter_files, wasted_bytes


def human_size(num_bytes: int) -> str:
    """Format a byte count like ``1.5 MB``."""
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dupefind",
        description="Find duplicate files in one or more folders.",
    )
    parser.add_argument("folders", nargs="+", type=Path, help="folders to scan")
    parser.add_argument(
        "--min-size",
        type=int,
        default=1,
        metavar="BYTES",
        help="ignore files smaller than this (default: 1)",
    )
    parser.add_argument(
        "--algorithm",
        default="sha256",
        choices=["md5", "sha1", "sha256", "blake2b"],
        help="hash algorithm (default: sha256)",
    )
    parser.add_argument("--json", action="store_true", help="output JSON")
    parser.add_argument("--version", action="version", version=__version__)
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    for folder in args.folders:
        if not folder.is_dir():
            print(f"error: not a directory: {folder}", file=sys.stderr)
            return 2

    files = (
        path
        for folder in args.folders
        for path in iter_files(folder, min_size=args.min_size)
    )
    groups = find_duplicates(files, algorithm=args.algorithm)

    if args.json:
        payload = {
            "groups": [[str(p) for p in paths] for paths in groups.values()],
            "wasted_bytes": wasted_bytes(groups),
        }
        print(json.dumps(payload, indent=2))
    elif not groups:
        print("No duplicates found.")
    else:
        for number, paths in enumerate(groups.values(), start=1):
            print(f"Group {number} ({human_size(paths[0].stat().st_size)} each):")
            for path in paths:
                print(f"  {path}")
        print(
            f"\n{len(groups)} duplicate group(s), "
            f"{human_size(wasted_bytes(groups))} reclaimable."
        )

    return 1 if groups else 0


if __name__ == "__main__":
    raise SystemExit(main())
