import json
from pathlib import Path

from dupefind.cli import human_size, main
from dupefind.scanner import find_duplicates, hash_file, iter_files, wasted_bytes


def make(tmp_path: Path, name: str, content: bytes) -> Path:
    path = tmp_path / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    return path


def test_finds_duplicates_across_subfolders(tmp_path):
    a = make(tmp_path, "a.txt", b"hello")
    b = make(tmp_path, "sub/b.txt", b"hello")
    make(tmp_path, "c.txt", b"different")

    groups = find_duplicates(iter_files(tmp_path))

    assert len(groups) == 1
    assert sorted(next(iter(groups.values()))) == sorted([a, b])


def test_same_size_different_content_is_not_duplicate(tmp_path):
    make(tmp_path, "a.bin", b"abcd")
    make(tmp_path, "b.bin", b"abce")

    assert find_duplicates(iter_files(tmp_path)) == {}


def test_min_size_filters_small_files(tmp_path):
    make(tmp_path, "a.txt", b"hi")
    make(tmp_path, "b.txt", b"hi")

    assert list(iter_files(tmp_path, min_size=10)) == []


def test_empty_files_ignored_by_default(tmp_path):
    make(tmp_path, "a.txt", b"")
    make(tmp_path, "b.txt", b"")

    assert find_duplicates(iter_files(tmp_path)) == {}


def test_wasted_bytes(tmp_path):
    for name in ("a", "b", "c"):
        make(tmp_path, name, b"12345")

    groups = find_duplicates(iter_files(tmp_path))

    assert wasted_bytes(groups) == 10  # keep one of three 5-byte copies


def test_hash_file_is_stable(tmp_path):
    path = make(tmp_path, "x", b"data")
    assert hash_file(path) == hash_file(path)
    assert hash_file(path, "md5") != hash_file(path, "sha256")


def test_human_size():
    assert human_size(512) == "512 B"
    assert human_size(2048) == "2.0 KB"


def test_cli_exit_codes_and_json(tmp_path, capsys):
    make(tmp_path, "a.txt", b"same")
    make(tmp_path, "b.txt", b"same")

    assert main([str(tmp_path), "--json"]) == 1
    payload = json.loads(capsys.readouterr().out)
    assert len(payload["groups"]) == 1
    assert payload["wasted_bytes"] == 4


def test_cli_no_duplicates(tmp_path, capsys):
    make(tmp_path, "a.txt", b"one")
    make(tmp_path, "b.txt", b"two")

    assert main([str(tmp_path)]) == 0
    assert "No duplicates found." in capsys.readouterr().out


def test_cli_bad_folder(tmp_path, capsys):
    assert main([str(tmp_path / "missing")]) == 2
    assert "not a directory" in capsys.readouterr().err
